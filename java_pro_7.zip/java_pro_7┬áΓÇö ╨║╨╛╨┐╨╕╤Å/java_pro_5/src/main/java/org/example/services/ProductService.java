package org.example.services;

import lombok.RequiredArgsConstructor;
import org.example.dao.ProductRepository;
import org.example.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getAllProducts(String id) {
        return productRepository.findProductsByUsersId(Long.valueOf(id));
    }

    public Product getProductByProductId(String id) {
        return productRepository.getProductById(Long.valueOf(id));
        }
}
