package org.example.dao;

import org.example.model.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest()
@ComponentScan("org.example")
class ProductUserDescriptionDaoTest {
    @Autowired
    private ProductRepository productRepository;

    @Test
    void getAllProducts() {
        List<Product> products = productRepository.findProductsByUsersId(1L);
        assertEquals(2, products.size());
        Collections.sort(products, Comparator.comparingLong(Product::getId));
        assertEquals("C12345", products.get(0).getAccount_number());
        assertEquals("C23451", products.get(1).getAccount_number());
        products = productRepository.findProductsByUsersId(2L);
        assertEquals(2, products.size());
        Collections.sort(products, Comparator.comparingLong(Product::getId));
        assertEquals("A34512", products.get(0).getAccount_number());
        assertEquals("C45123", products.get(1).getAccount_number());
        products = productRepository.findProductsByUsersId(3L);
        assertEquals(1, products.size());
        assertEquals("A51234", products.get(0).getAccount_number());
    }

    @Test
    void getProductByProductId() {
        Product products = productRepository.getProductById(1L);
        assertEquals("C12345", products.getAccount_number());
        products = productRepository.getProductById(2L);
        assertEquals("C23451", products.getAccount_number());
        products = productRepository.getProductById(3L);
        assertEquals("A34512", products.getAccount_number());
        products = productRepository.getProductById(4L);
        assertEquals("C45123", products.getAccount_number());
        products = productRepository.getProductById(5L);
        assertEquals("A51234", products.getAccount_number());
        }
}