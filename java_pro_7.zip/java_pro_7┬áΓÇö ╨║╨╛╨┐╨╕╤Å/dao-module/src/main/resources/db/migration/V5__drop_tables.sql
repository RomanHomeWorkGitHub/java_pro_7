DROP TABLE users2;
DROP TABLE product2;
