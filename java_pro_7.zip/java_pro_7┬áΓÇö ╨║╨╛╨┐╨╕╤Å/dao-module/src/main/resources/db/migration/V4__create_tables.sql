CREATE TABLE users2 (id bigserial primary key, username varchar(255) unique);
CREATE TABLE product2 (id bigserial primary key, account_number varchar(255) unique, balance decimal, product_type varchar(3), users_id bigserial);

INSERT INTO users2 (id, username)
VALUES (1, 'Вася1'),
       (2, 'Вася2'),
       (3, 'Вася3');
INSERT INTO product2 (id, account_number, balance, product_type, users_id)
VALUES (1, 'C12345', 100, 'CRD', 1),
       (2, 'C23451', 101, 'CRD',1),
     (3, 'A34512', 102, 'ACC', 2),
     (4, 'C45123', 110, 'CRD',2),
     (5, 'A51234', 111, 'ACC',3);

