package org.example.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    @Column(name = "account_number")
    String account_number;
    @Column(name = "balance")
    BigDecimal balance;
    @Column(name = "product_type")
    @Enumerated(EnumType.STRING)
    ProducTypeEnum product_type;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "users_id")
    @JsonIgnore
    private Users users;

    public enum ProducTypeEnum  {
        ACC, CRD;
    }

    @Enumerated(EnumType.STRING)
    public ProducTypeEnum getProducTypeEnum() {
        return product_type;
    }
}
